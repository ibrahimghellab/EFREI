package exo1;

public interface Paiement {
    String effectuerPaiement(double montant);

}
